package com.cts.postal.service;

import org.springframework.stereotype.Service;

import com.cts.postal.model.postal;

public interface postal_service {
	
	public postal getSearch(String thePin);

}
