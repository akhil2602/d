package com.cts.postal.DAO;

import org.springframework.stereotype.Repository;

import com.cts.postal.model.postal;


public interface postalDao {

	public postal getSearch(String thePin);
}
